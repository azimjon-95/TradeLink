import React from "react";
import FeeHistory from "../../components/dashboard/feeHistory/FeeHistory";

function SuccessFeeHistiry() {
  return (
    <div>
      <FeeHistory />
    </div>
  );
}

export default SuccessFeeHistiry;
