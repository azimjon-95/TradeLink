import React from "react";
import "./HubContainer.css";

function HubContainer() {
  return <div className="hub-container"></div>;
}

export default HubContainer;
