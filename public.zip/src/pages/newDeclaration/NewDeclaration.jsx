import React from "react";
import Declaration from "../../components/createDeclaration/Declaration";

function NewDeclaration() {
  return (
    <>
      <Declaration />
    </>
  );
}

export default NewDeclaration;
