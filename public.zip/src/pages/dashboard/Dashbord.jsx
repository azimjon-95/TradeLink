import React from "react";
import "./Dashboard.css";
import Dashboard from "../../components/dashboard/Dashboard";

function Dashbord() {
  return (
    <div className="Dashboard">
      <Dashboard />
    </div>
  );
}

export default Dashbord;
