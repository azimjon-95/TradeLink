export const langText = {
  en: {
    commandCenter_title: "Your All-in-One Crypto Trading Hub.",
  },
  ru: {
    commandCenter_title: "Ваш все-в-одном крипто-торговый хаб.",
  },
  es: {
    commandCenter_title: "Tu centro de trading de criptomonedas todo en uno.",
  },
  de: {
    commandCenter_title: "Ihr zentrales Kryptotrading-Hub.",
  },
};
