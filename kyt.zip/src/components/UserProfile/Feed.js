import React from 'react'

const Feed = () => {
    return (
        <div>
            <h1>Feed</h1>
        </div>
    )
}


export default Feed
