
import React from "react";
import Section from "../../components/passport/section/Section";



const Passport = () => {
  let style = {
    width: "100%",
  };
  return (
    <div style={style} className="passport">
      <Section />

    </div>
  );
};

export default Passport;
