import React from "react";
import Banner from "../../components/banner/Banner";

function Home() {
  return (
    <>
      <Banner />

    </>
  );
}

export default Home;
